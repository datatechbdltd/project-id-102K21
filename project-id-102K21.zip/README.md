#Information website using Laravel Starter of DATATECH DB LTD

1. Git clone
2. Composer install
3. .env.example to .env
4. php artisan migrate:fresh --seed
