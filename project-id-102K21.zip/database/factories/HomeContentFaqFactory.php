<?php

namespace Database\Factories;

use App\Models\HomeContentFaq;
use Illuminate\Database\Eloquent\Factories\Factory;

class HomeContentFaqFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = HomeContentFaq::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
