<footer class="footer">
    <p class="mb-0">{!! get_static_option('footer_credit') !!}</p>
</footer>
